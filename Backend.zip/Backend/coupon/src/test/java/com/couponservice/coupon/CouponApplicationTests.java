package com.couponservice.coupon;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.couponservice.controller.CouponController;
import com.couponservice.repository.CouponRepository;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@SpringBootTest
class CouponApplicationTests {

    @MockBean
    CouponRepository couponRepository;

    @Autowired
    CouponController couponController;   


    @Test
    public void getAllCouponsTest() {
        when(couponRepository.findAll()).thenReturn(
                Stream.of(
                                new Coupon("", "amazon", "amaz1222", "mobiles", "15% offer","12-10-2022"))
                        .collect(Collectors.toList()));
        assertEquals(1, couponController.getAllCoupons().size());

    }
    
//    @Test
//    public void addCouponTest() {
//    	Coupon coupons = new Coupon("", "amazon", "ama1222", "mobiles", "15% offer","20-10-2022");
//        when(couponRepository.save(coupons)).thenReturn((coupons));
//        assertEquals(coupons, couponController.addCoupon(coupons));
//    }
//
//    @Test
//    public void addCouponTest() {
//        Coupon coupons = new Coupon("", "amazon", "ama1222", "mobiles", "15% offer","20-10-2022");
//        when(couponRepository.save(coupons)).thenReturn(coupons);
//        assertEquals(coupons, couponController.addCoupon(coupons));
//    }

    @Test
    public void deleteDealTest() {

        String couponId = "1";

        Coupon coupon = new Coupon("1", "amazon", "ama1222", "mobiles", "15% offer","12-10-22");
        couponRepository.deleteById(couponId);
        verify(couponRepository).deleteById(couponId);


    }
}