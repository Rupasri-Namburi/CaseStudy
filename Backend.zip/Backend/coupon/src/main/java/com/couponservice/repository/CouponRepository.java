package com.couponservice.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.couponservice.coupon.Coupon;

public interface  CouponRepository extends MongoRepository<Coupon, String> {

    //Coupon findProductById(String Id);

}
